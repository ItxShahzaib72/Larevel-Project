@extends('admintemplate')
@section('admincontent')

<div class="container">
    <div class="row">
        <div class="col text-center mt-3">
            <h2>Categories</h2>
        </div>
    </div>
    <div class="row p-3">
        <div class="col-3 mt-3">
            <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#addCategory">Add Category</button>
        </div>
    </div>
    <div class="row m-1 ">
        <div class="col">
            {{-- <a href="" class="btn btn-secondary">Add Category</a> --}}
            <table class="table table-bordered mt-3">
                <thead>
                    <tr>
                    <th class="text-white">S.no</th>
                    <th class="text-white">ID</th>
                    <th class="text-white" >Name</th>
                    <th class="text-white" >Image</th>
                    <th class="text-white" >Status</th>
                    <th class="text-white">Action</th>



                </tr>
                </thead>

                <tbody>
                 @foreach ($Category as $item)
                    <tr>
                        <td class="text-white" >{{$loop->iteration}}</td>
                        <td class="text-white">{{$item->categoryId}}</td>
                        <td class="text-white">{{$item->categoryName}}</td>
                        <td class="text-white">{{$item->categoryImage}}</td>
                        <td class="text-white">{{$item->categoryStatus}}</td>
                        <td class="text-white"><button class="btn btn-info"     style="margin-top: -5px ">Edit</button></td>
                        <td class="text-white"><button class="btn btn-success"  style="margin-top: -5px ">Update</button></td>
                        <td class="text-white"><button class="btn btn-primary"  style="margin-top: -5px ">Delete</button></td>
                    </tr>
                 @endforeach
                <tbody>
                <hr>
            </table>
            <hr>
</div>


{{-- add category modal  --}}

<!-- Modal -->
<div class="modal fade" id="addCategory" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title text-dark" id="exampleModalLabel">Modal title</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>


        <form action="/Categories" method="POST" >
            @csrf
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Category Name</label>
                    <input type="text" name="categoryName" class="form-control" placeholder="Enter Category Name">
                  </div>
                  <div class="mb-3">
                    <label class="form-label">Category Image</label>
                    <input type="file" name="categoryImage" class="form-control" placeholder="">
                  </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-success">Save</button>
            </div>
          </div>
        </form>


    </div>
  </div>

@endsection
