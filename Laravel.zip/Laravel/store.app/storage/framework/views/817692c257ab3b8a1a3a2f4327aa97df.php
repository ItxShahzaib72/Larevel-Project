<?php $__env->startSection('admincontent'); ?>

<div class="container">
    <div class="row">
        <div class="col text-center mt-3">
            <h2>Products</h2>
        </div>
    </div>
    <div class="row p-3">
        <div class="col-3 mt-3">
            <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#addCategory">Add Products</button>
        </div>
    </div>
    <div class="row m-1 ">
        <div class="col">
            
            <table class="table table-bordered mt-3">
                <thead>
                    <tr>
                    <th class="text-white">S.no</th>
                    <th class="text-white">ID</th>
                    <th class="text-white">CategoryID</th>
                    <th class="text-white" >Name</th>
                    <th class="text-white" >Description</th>
                    <th class="text-white" >Image</th>
                    <th class="text-white" >Quantity</th>
                    <th class="text-white" >Price</th>
                    <th class="text-white" >Status</th>
                    <th class="text-white">Action</th>



                </tr>
                </thead>

                <tbody>
                 <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-white" ><?php echo e($loop->iteration); ?></td>
                        <td class="text-white"><?php echo e($item->ProductId); ?></td>
                        <td class="text-white"><?php echo e($item->CategorytId); ?></td>
                        <td class="text-white"><?php echo e($item->ProductName); ?></td>
                        <td class="text-white"><?php echo e($item->ProductDescription); ?></td>
                        <td class="text-white"><?php echo e($item->ProductImage); ?></td>
                        <td class="text-white"><?php echo e($item->ProductQuantity); ?></td>
                        <td class="text-white"><?php echo e($item->ProductPrice); ?></td>
                        <td class="text-white"><?php echo e($item->ProductStatus); ?></td>
                        <td class="text-white"><button class="btn btn-info"     style="margin-top: -5px ">Edit</button></td>
                        <td class="text-white"><button class="btn btn-success"  style="margin-top: -5px ">Update</button></td>
                        <td class="text-white"><button class="btn btn-primary"  style="margin-top: -5px ">Delete</button></td>
                    </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                <hr>
            </table>
            <hr>
</div>




<!-- Modal -->
<div class="modal fade" id="addCategory" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title text-dark" id="exampleModalLabel">Modal title</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>


        <form action="/Products" method="POST" >
            <?php echo csrf_field(); ?>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Product Name</label>
                    <input type="text" name="Name" class="form-control" placeholder="Enter Product Name">
                  </div>
                  <div class="mb-3">
                    <label class="form-label">Product Decription</label>
                    <input type="text" name="Description" class="form-control" placeholder="Enter Product Description">
                  </div>
                  <div class="mb-3">
                    <label class="form-label">Product Quantity</label>
                    <input type="numbers" name="Quantity" class="form-control" placeholder="Enter Product Quantity">
                  </div>
                  <div class="mb-3">
                    <label class="form-label">Product Price</label>
                    <input type="numbers" name="Price" class="form-control" placeholder="Enter Product Price">
                  </div>
                  <div class="mb-3">
                    <label class="form-label">Product Image</label>
                    <input type="file" name="Image" class="form-control" placeholder="">
                  </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-success">Save</button>
            </div>
          </div>
        </form>


    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admintemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\shahzaib2309a\Laravel\store.app\resources\views/adminlayouts/products.blade.php ENDPATH**/ ?>