 
 <?php $__env->startSection('logincontent'); ?>


	<!-- Start Banner Area -->
	
	<!-- End Banner Area -->

	<!--================Login Box Area =================-->
	<section class="login_box_area section_gap">
		<div class="container">
			<div class="row">
				
				<div class="col-lg-12">
					<div class="login_form_inner">
						<h3>Reset Your Password</h3>
                        
                     
						<form method="POST" action="<?php echo e(route('password.email')); ?>" class="row login_form" id="contactForm" novalidate="novalidate">
                            <?php echo csrf_field(); ?>
                            <div class="mb-4 text-sm text-gray-600">
                                <?php echo e(__('Forgot your password? No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one.')); ?>

                            </div>
                            <?php $__sessionArgs = ['status'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
            <div class="mb-4 font-medium text-sm text-green-600">
                <?php echo e($value); ?>

            </div>
        <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>



                            <div class="col-md-12 form-group"  value="<?php echo e(__('Email')); ?>">
								<input type="email" class="form-control" id="email" name="email" placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email'":value="old('email')" required autofocus autocomplete="username" >
							</div>
							
                            
                            <div class="col-md-12 form-group">
								<button type="submit" value="submit" class="primary-btn">     <?php echo e(__('  Reset Password')); ?></button>
								
							</div>
							
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--================End Login Box Area =================-->

<?php $__env->stopSection(); ?> 

<?php echo $__env->make('hometemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Class Material\Laravel\store.app\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>