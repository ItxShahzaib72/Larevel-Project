
<?php $__env->startSection('admincontent'); ?>

<div class="container">
    <div class="row">
        <div class="col text-center mt-3">
            <h2>Categories</h2>
        </div>
    </div>
    <div class="row p-3">
        <div class="col-3 mt-3">
            <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#addCategory">Add Category</button>
        </div>
    </div>
    <div class="row m-1 ">
        <div class="col">
            
            <table class="table table-bordered mt-3">
                <thead>
                <tr>
                    <th class="text-white">ID</th>
                    <th class="text-white" >Name</th>
                    <th class="text-white" >Image</th>
                    <th class="text-white" >Status</th>
                    <th class="text-white" >Action</th>
                    

                                            
                </tr>
                </thead>
            </table>

</div>




<!-- Modal -->
<div class="modal fade" id="addCategory" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title text-dark" id="exampleModalLabel">Modal title</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          ...
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-secondary">Save changes</button>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admintemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Class Material\Laravel\store.app\resources\views/adminlayouts/categories.blade.php ENDPATH**/ ?>